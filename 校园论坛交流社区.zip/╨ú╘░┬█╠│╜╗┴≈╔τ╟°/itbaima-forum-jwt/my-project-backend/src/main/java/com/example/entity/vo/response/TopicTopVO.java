package com.example.entity.vo.response;

import lombok.Data;

import java.util.Date;

@Data
public class TopicTopVO {
    int id;
    String title;
    Date time;
}

package com.example.entity.vo.response;

import lombok.Data;

@Data
public class AccountDetailsVO {
    int gender;
    String phone;
    String qq;
    String wx;
    String desc;
}

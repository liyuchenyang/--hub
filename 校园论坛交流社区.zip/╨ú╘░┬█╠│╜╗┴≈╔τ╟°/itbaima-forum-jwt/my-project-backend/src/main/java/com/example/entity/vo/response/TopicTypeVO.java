package com.example.entity.vo.response;

import lombok.Data;

@Data
public class TopicTypeVO {
    int id;
    String name;
    String desc;
    String color;
}
